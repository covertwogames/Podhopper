package au.com.shiftyjelly.pocketcasts.ui

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.Toolbar
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnLayout
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_Y
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.commitNow
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.Observer
import androidx.lifecycle.asFlow
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.flowWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.mediarouter.media.MediaControlIntent
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import androidx.transition.Slide
import au.com.shiftyjelly.pocketcasts.R
import au.com.shiftyjelly.pocketcasts.account.AccountActivity
import au.com.shiftyjelly.pocketcasts.account.PromoCodeUpgradedFragment
import au.com.shiftyjelly.pocketcasts.account.onboarding.AccountBenefitsFragment
import au.com.shiftyjelly.pocketcasts.account.onboarding.OnboardingActivity
import au.com.shiftyjelly.pocketcasts.account.onboarding.OnboardingActivityContract
import au.com.shiftyjelly.pocketcasts.account.onboarding.OnboardingActivityContract.OnboardingFinish
import au.com.shiftyjelly.pocketcasts.account.onboarding.podhopper.PodHopperOnboardingActivity
import au.com.shiftyjelly.pocketcasts.account.watchsync.WatchSync
import au.com.shiftyjelly.pocketcasts.analytics.SourceView
import au.com.shiftyjelly.pocketcasts.appreview.AppReviewDialogFragment
import au.com.shiftyjelly.pocketcasts.compose.AppTheme
import au.com.shiftyjelly.pocketcasts.compose.components.AnimatedNonNullVisibility
import au.com.shiftyjelly.pocketcasts.compose.components.PlaybackErrorInfoBar
import au.com.shiftyjelly.pocketcasts.coroutines.di.ApplicationScope
import au.com.shiftyjelly.pocketcasts.databinding.ActivityMainBinding
import au.com.shiftyjelly.pocketcasts.deeplink.AddBookmarkDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.AppOpenDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.AssistantDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ChangeBookmarkTitleDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.CloudFilesDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.CreateAccountDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.DeepLink.Companion.EXTRA_PAGE
import au.com.shiftyjelly.pocketcasts.deeplink.DeepLinkFactory
import au.com.shiftyjelly.pocketcasts.deeplink.DeleteBookmarkDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.DeveloperOptionsDeeplink
import au.com.shiftyjelly.pocketcasts.deeplink.DownloadsDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ImportDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.NativeShareDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.OpmlImportDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.PlayFromSearchDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.PocketCastsWebsiteGetDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.PromoCodeDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.RecommendationsDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ReferralsDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ShareListDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ShowBookmarkDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ShowDiscoverDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ShowEpisodeDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ShowFiltersDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ShowPlaylistDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ShowPodcastDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ShowPodcastFromUrlDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ShowPodcastsDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ShowUpNextModalDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ShowUpNextTabDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.SignInDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.SmartFoldersDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.SonosDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.StaffPicksDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.ThemesDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.TrendingDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.UpgradeAccountDeepLink
import au.com.shiftyjelly.pocketcasts.deeplink.UpsellDeepLink
import au.com.shiftyjelly.pocketcasts.discover.util.DiscoverDeepLinkManager
import au.com.shiftyjelly.pocketcasts.discover.util.DiscoverDeepLinkManager.Companion.RECOMMENDATIONS_USER
import au.com.shiftyjelly.pocketcasts.discover.util.DiscoverDeepLinkManager.Companion.STAFF_PICKS_LIST_ID
import au.com.shiftyjelly.pocketcasts.discover.view.PodcastGridListFragment
import au.com.shiftyjelly.pocketcasts.discover.view.PodcastListFragment
import au.com.shiftyjelly.pocketcasts.endofyear.StoriesActivity
import au.com.shiftyjelly.pocketcasts.endofyear.StoriesActivity.StoriesSource
import au.com.shiftyjelly.pocketcasts.endofyear.ui.EndOfYearLaunchBottomSheet
import au.com.shiftyjelly.pocketcasts.models.entity.Podcast
import au.com.shiftyjelly.pocketcasts.models.entity.PodcastEpisode
import au.com.shiftyjelly.pocketcasts.models.entity.UserEpisode
import au.com.shiftyjelly.pocketcasts.models.type.EpisodeViewSource
import au.com.shiftyjelly.pocketcasts.models.type.SignInState
import au.com.shiftyjelly.pocketcasts.navigation.BottomNavigator
import au.com.shiftyjelly.pocketcasts.navigation.FragmentInfo
import au.com.shiftyjelly.pocketcasts.navigation.NavigatorAction
import au.com.shiftyjelly.pocketcasts.payment.PaymentClient
import au.com.shiftyjelly.pocketcasts.player.view.PlaybackIssuesBottomSheetFragment
import au.com.shiftyjelly.pocketcasts.player.view.PlayerBottomSheet
import au.com.shiftyjelly.pocketcasts.player.view.PlayerContainerFragment
import au.com.shiftyjelly.pocketcasts.player.view.UpNextFragment
import au.com.shiftyjelly.pocketcasts.player.view.bookmark.BookmarkActivity
import au.com.shiftyjelly.pocketcasts.player.view.bookmark.BookmarkActivityContract
import au.com.shiftyjelly.pocketcasts.player.view.bookmark.BookmarksContainerFragment
import au.com.shiftyjelly.pocketcasts.player.view.dialog.MiniPlayerDialog
import au.com.shiftyjelly.pocketcasts.player.view.video.VideoActivity
import au.com.shiftyjelly.pocketcasts.playlists.PlaylistFragment
import au.com.shiftyjelly.pocketcasts.playlists.PlaylistsFragment
import au.com.shiftyjelly.pocketcasts.podcasts.view.ProfileEpisodeListFragment
import au.com.shiftyjelly.pocketcasts.podcasts.view.episode.EpisodeContainerFragment
import au.com.shiftyjelly.pocketcasts.podcasts.view.folders.SuggestedFoldersFragment
import au.com.shiftyjelly.pocketcasts.podcasts.view.podcast.PodcastFragment
import au.com.shiftyjelly.pocketcasts.podcasts.view.podcasts.PodcastsFragment
import au.com.shiftyjelly.pocketcasts.podcasts.view.share.ShareListIncomingFragment
import au.com.shiftyjelly.pocketcasts.preferences.Settings
import au.com.shiftyjelly.pocketcasts.preferences.model.AppReviewReason
import au.com.shiftyjelly.pocketcasts.profile.ProfileFragment
import au.com.shiftyjelly.pocketcasts.profile.SubCancelledFragment
import au.com.shiftyjelly.pocketcasts.profile.TrialFinishedFragment
import au.com.shiftyjelly.pocketcasts.profile.cloud.CloudFileBottomSheetFragment
import au.com.shiftyjelly.pocketcasts.profile.cloud.CloudFilesFragment
import au.com.shiftyjelly.pocketcasts.profile.sonos.SonosAppLinkActivity
import au.com.shiftyjelly.pocketcasts.referrals.ReferralsGuestPassFragment
import au.com.shiftyjelly.pocketcasts.repositories.appreview.AppReviewManager
import au.com.shiftyjelly.pocketcasts.repositories.bumpstats.BumpStatsTask
import au.com.shiftyjelly.pocketcasts.repositories.di.NotificationPermissionChecker
import au.com.shiftyjelly.pocketcasts.repositories.endofyear.EndOfYearManager
import au.com.shiftyjelly.pocketcasts.repositories.notification.NotificationHelper
import au.com.shiftyjelly.pocketcasts.repositories.opml.OpmlImportTask
import au.com.shiftyjelly.pocketcasts.repositories.playback.PlaybackManager
import au.com.shiftyjelly.pocketcasts.repositories.playback.PlaybackNoticeType
import au.com.shiftyjelly.pocketcasts.repositories.playback.PlaybackState
import au.com.shiftyjelly.pocketcasts.repositories.playback.UpNextSource
import au.com.shiftyjelly.pocketcasts.repositories.playlist.Playlist
import au.com.shiftyjelly.pocketcasts.repositories.podcast.EpisodeManager
import au.com.shiftyjelly.pocketcasts.repositories.podcast.PodcastManager
import au.com.shiftyjelly.pocketcasts.repositories.podcast.UserEpisodeManager
import au.com.shiftyjelly.pocketcasts.repositories.podhopper.PodHopperPositionSync
import au.com.shiftyjelly.pocketcasts.repositories.podhopper.PodHopperSubscriptionSync
import au.com.shiftyjelly.pocketcasts.repositories.refresh.RefreshPodcastsTask
import au.com.shiftyjelly.pocketcasts.repositories.sync.SyncManager
import au.com.shiftyjelly.pocketcasts.search.AddPodcastFragment
import au.com.shiftyjelly.pocketcasts.search.SearchFragment
import au.com.shiftyjelly.pocketcasts.servers.ServiceManager
import au.com.shiftyjelly.pocketcasts.servers.model.NetworkLoadableList.Companion.TRENDING
import au.com.shiftyjelly.pocketcasts.settings.AppearanceSettingsFragment
import au.com.shiftyjelly.pocketcasts.settings.ExportSettingsFragment
import au.com.shiftyjelly.pocketcasts.settings.SettingsFragment
import au.com.shiftyjelly.pocketcasts.settings.developer.DeveloperFragment
import au.com.shiftyjelly.pocketcasts.settings.onboarding.OnboardingFlow
import au.com.shiftyjelly.pocketcasts.settings.onboarding.OnboardingLauncher
import au.com.shiftyjelly.pocketcasts.settings.onboarding.OnboardingUpgradeSource
import au.com.shiftyjelly.pocketcasts.settings.whatsnew.WhatsNewFragment
import au.com.shiftyjelly.pocketcasts.ui.MainActivityViewModel.NavigationState
import au.com.shiftyjelly.pocketcasts.ui.helper.FragmentHostListener
import au.com.shiftyjelly.pocketcasts.ui.helper.NavigationBarColor
import au.com.shiftyjelly.pocketcasts.ui.helper.StatusBarIconColor
import au.com.shiftyjelly.pocketcasts.ui.theme.Theme
import au.com.shiftyjelly.pocketcasts.utils.Network
import au.com.shiftyjelly.pocketcasts.utils.Util
import au.com.shiftyjelly.pocketcasts.utils.featureflag.Feature
import au.com.shiftyjelly.pocketcasts.utils.featureflag.FeatureFlag
import au.com.shiftyjelly.pocketcasts.utils.log.LogBuffer
import au.com.shiftyjelly.pocketcasts.utils.observeOnce
import au.com.shiftyjelly.pocketcasts.view.LockableBottomSheetBehavior
import au.com.shiftyjelly.pocketcasts.views.activity.WebViewActivity
import au.com.shiftyjelly.pocketcasts.views.extensions.showAllowingStateLoss
import au.com.shiftyjelly.pocketcasts.views.extensions.spring
import au.com.shiftyjelly.pocketcasts.views.fragments.BaseDialogFragment
import au.com.shiftyjelly.pocketcasts.views.fragments.BaseFragment
import au.com.shiftyjelly.pocketcasts.views.fragments.TopScrollable
import au.com.shiftyjelly.pocketcasts.views.helper.HasBackstack
import au.com.shiftyjelly.pocketcasts.views.helper.OffsettingBottomSheetCallback
import au.com.shiftyjelly.pocketcasts.views.helper.UiUtil
import au.com.shiftyjelly.pocketcasts.views.helper.WarningsHelper
import com.automattic.android.tracks.crashlogging.CrashLogging
import com.automattic.eventhorizon.DiscoverTabOpenedEvent
import com.automattic.eventhorizon.EndOfYearModalDismissedEvent
import com.automattic.eventhorizon.EndOfYearModalShownEvent
import com.automattic.eventhorizon.EndOfYearModalTappedEvent
import com.automattic.eventhorizon.EventHorizon
import com.automattic.eventhorizon.FiltersTabOpenedEvent
import com.automattic.eventhorizon.PlaybackErrorShownEvent
import com.automattic.eventhorizon.PlaybackErrorTappedEvent
import com.automattic.eventhorizon.PlayerErrorBannerSource
import com.automattic.eventhorizon.PodcastsTabOpenedEvent
import com.automattic.eventhorizon.ProfileTabOpenedEvent
import com.automattic.eventhorizon.UpNextDismissedEvent
import com.automattic.eventhorizon.UpNextShownEvent
import com.automattic.eventhorizon.UpNextSourceType
import com.automattic.eventhorizon.UpNextTabOpenedEvent
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import kotlin.coroutines.CoroutineContext
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import android.provider.Settings as AndroidProviderSettings
import au.com.shiftyjelly.pocketcasts.localization.R as LR
import au.com.shiftyjelly.pocketcasts.views.R as VR

private const val SAVEDSTATE_BOTTOM_SHEET_TAG = "bottom_sheet_tag"
private const val EXTRA_LONG_SNACKBAR_DURATION_MS: Int = 5000

@AndroidEntryPoint
class MainActivity :
    AppCompatActivity(),
    FragmentHostListener,
    PlayerBottomSheet.PlayerBottomSheetListener,
    SearchFragment.Listener,
    OnboardingLauncher,
    CoroutineScope,
    NotificationPermissionChecker {

    companion object {
        private const val INITIAL_KEY = "initial"
        private const val SOURCE_KEY = "source"

        init {
            AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
        }

        const val PROMOCODE_REQUEST_CODE = 2
    }

    @Inject
    lateinit var playbackManager: PlaybackManager

    @Inject
    lateinit var podHopperPositionSync: PodHopperPositionSync

    @Inject
    lateinit var podHopperSubscriptionSync: PodHopperSubscriptionSync

    @Inject
    lateinit var podcastManager: PodcastManager

    @Inject
    lateinit var episodeManager: EpisodeManager

    @Inject
    lateinit var serviceManager: ServiceManager

    @Inject
    lateinit var theme: Theme

    @Inject
    lateinit var settings: Settings

    @Inject
    lateinit var userEpisodeManager: UserEpisodeManager

    @Inject
    lateinit var warningsHelper: WarningsHelper

    @Inject
    lateinit var eventHorizon: EventHorizon

    @Inject
    lateinit var syncManager: SyncManager

    @Inject
    lateinit var watchSync: WatchSync

    @Inject
    lateinit var notificationHelper: NotificationHelper

    @Inject
    lateinit var discoverDeepLinkManager: DiscoverDeepLinkManager

    @Inject
    @ApplicationScope
    lateinit var applicationScope: CoroutineScope

    @Inject
    lateinit var crashLogging: CrashLogging

    @Inject
    lateinit var paymentClient: PaymentClient

    @Inject
    lateinit var appReviewManager: AppReviewManager

    private val viewModel: MainActivityViewModel by viewModels()
    private val disposables = CompositeDisposable()
    private var videoPlayerShown: Boolean = false
    private var overrideNextRefreshTimer: Boolean = false

    private var mediaRouter: MediaRouter? = null
    private val mediaRouterCallback = object : MediaRouter.Callback() {}
    private val mediaRouteSelector = MediaRouteSelector.Builder()
        .addControlCategory(MediaControlIntent.CATEGORY_REMOTE_PLAYBACK)
        .build()

    private val childrenWithBackStack: List<HasBackstack>
        get() = supportFragmentManager.fragments.filterIsInstance<HasBackstack>()

    @Suppress("UNCHECKED_CAST")
    private val frameBottomSheetBehavior: LockableBottomSheetBehavior<View>
        get() = BottomSheetBehavior.from(binding.frameBottomSheet) as LockableBottomSheetBehavior<View>

    private val miniPlayerHeight: Int
        get() = resources.getDimension(R.dimen.miniPlayerHeight).toInt()

    private val bottomNavigationHeight: Int
        get() = binding.bottomContainer.height - binding.bottomContainer.paddingBottom

    private var bottomSheetTag: String? = null
    private val bottomSheetQueue: MutableList<(() -> Unit)?> = mutableListOf()

    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Default

    private lateinit var binding: ActivityMainBinding
    private lateinit var navigator: BottomNavigator

    private val podHopperOnboardingLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            openTab(VR.id.navigation_podcasts)
        }

    private val onboardingLauncher: ActivityResultLauncher<Intent> = registerForActivityResult(OnboardingActivityContract()) { result ->
        when (result) {
            is OnboardingFinish.Done -> {
                if (!settings.hasCompletedOnboarding()) {
                    lifecycleScope.launch { openLandingTabAfterOnboarding() }
                }
                settings.setHasDoneInitialOnboarding()
            }

            is OnboardingFinish.DoneGoToDiscover -> {
                settings.setHasDoneInitialOnboarding()
                openTab(VR.id.navigation_podcasts)
            }

            is OnboardingFinish.DoneShowPlusPromotion -> {
                lifecycleScope.launch {
                    if (!settings.hasCompletedOnboarding()) {
                        openLandingTabAfterOnboarding()
                    }
                    settings.setHasDoneInitialOnboarding()
                    OnboardingLauncher.openOnboardingFlow(this@MainActivity, OnboardingFlow.Upsell(OnboardingUpgradeSource.FINISHED_ONBOARDING))
                }
            }

            is OnboardingFinish.DoneShowWelcomeInReferralFlow -> {
                settings.showReferralWelcome.set(true, updateModifiedAt = false)
            }

            is OnboardingFinish.DoneApplySuggestedFolders, null -> {
                Timber.e("Unexpected result $result from onboarding activity")
            }
        }
    }

    private val bookmarkActivityLauncher: ActivityResultLauncher<Intent> = registerForActivityResult(
        BookmarkActivityContract(),
    ) { result ->
        showViewBookmarksSnackbar(result)
    }

    private val endOfYearActivityLauncher: ActivityResultLauncher<Intent> = registerForActivityResult(StoriesActivity.StoriesActivityContract()) { result ->
        when (result) {
            is StoriesActivity.StoriesActivityContract.Result.Failure -> {
                result.source?.let { source ->
                    val view = snackBarView()
                    val action = View.OnClickListener {
                        showStories(source = source)
                    }
                    Snackbar.make(view, getString(LR.string.end_of_year_failed_to_load_message), Snackbar.LENGTH_LONG)
                        .setAction(LR.string.retry, action)
                        .show()
                }
            }

            else -> Unit
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) {}

    private val deepLinkFactory = DeepLinkFactory()

    @SuppressLint("WrongConstant") // for custom snackbar duration constant
    private fun checkForNotificationPermission(onPermissionGranted: () -> Unit = {}) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when {
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED -> {
                    onPermissionGranted()
                }

                shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) -> {
                    if (settings.isNotificationsDisabledMessageShown()) return
                    Snackbar.make(
                        snackBarView(),
                        getString(LR.string.notifications_blocked_warning),
                        EXTRA_LONG_SNACKBAR_DURATION_MS,
                    ).setAction(
                        getString(LR.string.notifications_blocked_warning_snackbar_action)
                            .uppercase(Locale.getDefault()),
                    ) {
                        // Responds to click on the action
                        val intent = Intent(AndroidProviderSettings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        val uri: Uri = Uri.fromParts("package", packageName, null)
                        intent.data = uri
                        startActivity(intent)
                    }.show()
                    settings.setNotificationsDisabledMessageShown(true)
                }

                else -> {
                    notificationPermissionLauncher.launch(
                        Manifest.permission.POST_NOTIFICATIONS,
                    )
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Timber.d("Main Activity onCreate")
        // Changing the theme draws the status and navigation bars as black, unless this is manually set
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)
        theme.setupThemeForConfig(this, resources.configuration)
        enableEdgeToEdge(navigationBarStyle = theme.getNavigationBarStyle(this))
        bottomSheetTag = savedInstanceState?.getString(SAVEDSTATE_BOTTOM_SHEET_TAG)

        playbackManager.setNotificationPermissionChecker(this)

        val hasCompletedOnboarding = settings.hasCompletedOnboarding()
        val isLoggedIn = syncManager.isLoggedIn()
        val showOnboarding = !hasCompletedOnboarding && !isLoggedIn
        val needsLoginPromptAfterRestore = settings.getNeedsLoginPromptAfterRestore()
        // Only show if savedInstanceState is null in order to avoid creating onboarding activity twice.
        if (showOnboarding && savedInstanceState == null) {
            podHopperOnboardingLauncher.launch(PodHopperOnboardingActivity.newInstance(this))
        }

        // After restore from backup, consume the restore flag on fresh launch so it can't
        // trigger later unexpectedly, and suppress the generic encouragement flag when this
        // path launches the same account encouragement flow.
        if (savedInstanceState == null && needsLoginPromptAfterRestore) {
            settings.setNeedsLoginPromptAfterRestore(false)
            if (!showOnboarding && !isLoggedIn) {
                settings.showFreeAccountEncouragement.set(false, updateModifiedAt = true)
                openOnboardingFlow(OnboardingFlow.AccountEncouragement)
            }
        }

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, windowInsets ->
            val insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            binding.root.updatePadding(left = insets.left, right = insets.right)
            binding.bottomContainer.updatePadding(bottom = insets.bottom)
            windowInsets
        }
        binding.bottomContainer.addOnLayoutChangeListener { view, _, _, _, _, _, _, _, _ ->
            binding.mainFragment.updatePadding(bottom = view.height)

            BottomSheetBehavior.from(binding.playerBottomSheet).apply {
                peekHeight = miniPlayerHeight + view.height
            }
        }

        binding.playbackIssueBar.apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                val playbackNotice by viewModel.playbackNoticeFlow.collectAsStateWithLifecycle()
                val playerOpen by viewModel.isPlayerOpenFlow.collectAsStateWithLifecycle()

                AppTheme(theme.activeTheme) {
                    AnimatedNonNullVisibility(
                        item = if (playerOpen) null else playbackNotice,
                        enter = slideInVertically(initialOffsetY = { it }) + expandVertically(expandFrom = Alignment.Top),
                        exit = slideOutVertically(targetOffsetY = { it }) + shrinkVertically(shrinkTowards = Alignment.Top),
                    ) { notice ->
                        LaunchedEffect(notice) {
                            if (!viewModel.isPlayerOpen) {
                                eventHorizon.track(PlaybackErrorShownEvent(playerSource = PlayerErrorBannerSource.MiniPlayer))
                            }
                        }
                        PlaybackErrorInfoBar(
                            message = notice.message,
                            linkText = notice.linkText,
                            onClick = when (notice.type) {
                                PlaybackNoticeType.PLAYBACK -> {
                                    {
                                        if (!viewModel.isPlayerOpen) {
                                            eventHorizon.track(PlaybackErrorTappedEvent(playerSource = PlayerErrorBannerSource.MiniPlayer))
                                        }
                                        PlaybackIssuesBottomSheetFragment.show(supportFragmentManager, notice.supportUrl)
                                    }
                                }

                                PlaybackNoticeType.CONNECTION_LOST -> null

                                PlaybackNoticeType.RECOVERY -> null
                            },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        }

        binding.bottomNavigation.inflateMenu(VR.menu.navigation)

        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.CREATED) {
                val isEligible = viewModel.isEndOfYearStoriesEligible()
                if (isEligible) {
                    if (settings.getEndOfYearShowModal()) {
                        setupEndOfYearLaunchBottomSheet()
                    }
                    if (settings.getEndOfYearShowBadge2025()) {
                        binding.bottomNavigation.getOrCreateBadge(VR.id.navigation_profile)
                    }
                }
            }
        }

        var selectedTab = settings.selectedTab()
        val tabs = buildMap {
            put(VR.id.navigation_podcasts) { FragmentInfo(PodcastsFragment(), true) }
            put(VR.id.navigation_discover) { FragmentInfo(AddPodcastFragment(), true) }
            put(VR.id.navigation_filters) { FragmentInfo(PlaylistsFragment(), true) }
            put(VR.id.navigation_profile) { FragmentInfo(ProfileFragment(), true) }
            put(VR.id.navigation_upnext) {
                FragmentInfo(
                    UpNextFragment.newInstance(
                        embedded = false,
                        source = UpNextSource.UP_NEXT_TAB,
                    ),
                    true,
                )
            }
        }

        if (!tabs.keys.contains(selectedTab)) {
            // Guard against tab ids changing and settings having an out of date copy
            settings.setSelectedTab(null)
            selectedTab = null
        }

        if (selectedTab == null) {
            // PodHopper: Discover is gone, so Podcasts is always the default landing tab.
            selectedTab = VR.id.navigation_podcasts
        }

        navigator = BottomNavigator.onCreateWithDetachability(
            fragmentContainer = R.id.mainFragment,
            modalContainer = R.id.fragmentOverBottomNav,
            bottomNavigationView = binding.bottomNavigation,
            rootFragmentsFactory = tabs,
            defaultTab = selectedTab,
            activity = this,
        )

        navigator.resetRootFragmentCommand()
            .subscribe({ fragment ->
                val didScroll = (fragment as? TopScrollable)?.scrollToTop()

                // Open search UI when tapping the Discover navigation button
                // while at the top of the Discover page already
                val discoverId = VR.id.navigation_discover
                val currentFragmentIsDiscover = navigator.currentTab() == discoverId
                if (currentFragmentIsDiscover && didScroll == false) {
                    val searchFragment = SearchFragment.newInstance(
                        floating = true,
                        onlySearchRemote = true,
                        source = SourceView.DISCOVER,
                    )
                    addFragment(searchFragment, onTop = true)
                }
            })
            .addTo(disposables)

        setupBackPressedCallbacks()

        setupPlayerViews(
            animateMiniPlayer = savedInstanceState == null,
        )

        setupBottomSheetTranslation()

        if (savedInstanceState == null) {
            trackTabOpened(selectedTab, isInitial = true)
        }
        navigator.infoStream()
            .doOnNext {
                updateSystemColors()

                // PodHopper: check for subscription changes from other devices whenever the user
                // navigates. Throttled in the sync class so rapid navigation does not spam requests.
                podHopperSubscriptionSync.pollSubscriptions()

                if (it is NavigatorAction.TabSwitched) {
                    val currentTab = navigator.currentTab()
                    if (settings.selectedTab() != currentTab) {
                        trackTabOpened(currentTab)
                        when (currentTab) {
                            VR.id.navigation_profile -> resetEoYBadgeIfNeeded()
                        }
                    }
                    settings.setSelectedTab(currentTab)
                } else if (it is NavigatorAction.NewFragmentAdded) {
                    if (navigator.currentTab() == VR.id.navigation_profile) {
                        resetEoYBadgeIfNeeded()
                    }
                }
            }
            .subscribe()
            .addTo(disposables)

        handleIntent(intent, savedInstanceState)

        updateSystemColors()

        mediaRouter = MediaRouter.getInstance(this)

        ThemeSettingObserver(this, theme, settings.themeReconfigurationEvents).observeThemeChanges()

        encourageAccountCreation()
        setupAppReviewPrompt()
    }

    private fun resetEoYBadgeIfNeeded() {
        if (binding.bottomNavigation.getBadge(VR.id.navigation_profile) != null &&
            settings.getEndOfYearShowBadge2025()
        ) {
            binding.bottomNavigation.removeBadge(VR.id.navigation_profile)
            settings.setEndOfYearShowBadge2025(false)
        }
    }

    private fun encourageAccountCreation() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                val encourageAccountCreation = settings.showFreeAccountEncouragement.value
                if (!encourageAccountCreation) {
                    return@repeatOnLifecycle
                }
                settings.showFreeAccountEncouragement.set(false, updateModifiedAt = true)

                val isSignedIn = viewModel.signInState.asFlow().first().isSignedIn
                if (isSignedIn) {
                    return@repeatOnLifecycle
                }

                if (Util.isTablet(this@MainActivity)) {
                    AccountBenefitsFragment().show(supportFragmentManager, "account_benefits_fragment")
                } else {
                    openOnboardingFlow(OnboardingFlow.AccountEncouragement)
                }
            }
        }
    }

    override fun launchIntent(onboardingFlow: OnboardingFlow): Intent {
        return OnboardingActivity.newInstance(this, onboardingFlow)
    }

    override fun openOnboardingFlow(onboardingFlow: OnboardingFlow) {
        onboardingLauncher.launch(
            launchIntent(onboardingFlow),
            ActivityOptionsCompat
                .makeCustomAnimation(this, R.anim.onboarding_enter, R.anim.onboarding_disappear),
        )
    }

    override fun onStart() {
        super.onStart()

        // PodHopper: pull the latest cross device positions when the app comes to the foreground.
        podHopperPositionSync.pullLatestPositions()

        // PodHopper: pull subscription changes too, so a podcast added on another device shows up
        // here even though we did not subscribe to anything locally to trigger it.
        podHopperSubscriptionSync.pullSubscriptions()

        // PodHopper: while the app is in the foreground, poll every 30s so an already open device
        // notices subscription changes from other devices without needing to be reopened.
        podHopperSubscriptionSync.startPeriodicSync()

        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (!videoPlayerShown && playbackManager.getCurrentEpisode()?.isVideo == true && playbackManager.isPlaybackLocal() && playbackManager.isPlaying() && viewModel.isPlayerOpen) {
                openFullscreenViewPlayer()
            } else {
                videoPlayerShown = false
            }
        }

        // Tell media router to discover routes
        mediaRouter?.addCallback(mediaRouteSelector, mediaRouterCallback, MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY)
    }

    override fun onStop() {
        super.onStop()

        // PodHopper: stop the foreground subscription poll loop while backgrounded.
        podHopperSubscriptionSync.stopPeriodicSync()

        // Remove the callback flag CALLBACK_FLAG_REQUEST_DISCOVERY on stop by calling
        // addCallback() again in order to tell the media router that it no longer
        // needs to invest effort trying to discover routes of these kinds for now.
        mediaRouter?.addCallback(mediaRouteSelector, mediaRouterCallback, 0)
    }

    private fun openFullscreenViewPlayer() {
        videoPlayerShown = true
        startActivity(VideoActivity.buildIntent(context = this))
    }

    override fun onResume() {
        super.onResume()

        refreshApp()
        BumpStatsTask.scheduleToRun(this)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(SAVEDSTATE_BOTTOM_SHEET_TAG, bottomSheetTag)
    }

    override fun overrideNextRefreshTimer() {
        overrideNextRefreshTimer = true
    }

    private fun refreshApp() {
        fun doRefresh() {
            if (overrideNextRefreshTimer) {
                podcastManager.refreshPodcasts("open app - ignore timer")
                overrideNextRefreshTimer = false
            } else {
                // delay the refresh to allow the UI to load
                Observable.timer(1, TimeUnit.SECONDS, Schedulers.io())
                    .doOnNext {
                        podcastManager.refreshPodcastsIfRequired(fromLog = "open app")
                    }
                    .subscribeBy(onError = { Timber.e(it) })
                    .addTo(disposables)
            }
        }

        // If the user chooses the advanced option to only sync on unmetered networks
        // then don't auto-refresh when the app resumes. Still let them swipe down though
        // to refresh if they wish and still schedule the worker to do updates
        if (settings.refreshPodcastsOnResume(Network.isUnmeteredConnection(this@MainActivity))) {
            doRefresh()
        }

        lifecycleScope.launch {
            paymentClient.acknowledgePendingPurchases()
        }

        // Schedule next refresh in the background
        RefreshPodcastsTask.scheduleOrCancel(this@MainActivity, settings)
    }

    @Suppress("DEPRECATION")
    private suspend fun refreshAppAndWait() = withContext(Dispatchers.Main) {
        val dialog = android.app.ProgressDialog.show(this@MainActivity, getString(LR.string.loading), getString(LR.string.please_wait), true)
        LogBuffer.i(LogBuffer.TAG_BACKGROUND_TASKS, "Running refresh from refresh and wait")
        RefreshPodcastsTask.runNowSync(application, applicationScope)

        UiUtil.hideProgressDialog(dialog)
    }

    override fun onDestroy() {
        super.onDestroy()
        disposables.clear()
        mediaRouter?.removeCallback(mediaRouterCallback)
    }

    /**
     * Registers all back-press callbacks on the [OnBackPressedDispatcher].
     *
     * Callbacks are registered in reverse priority order (lowest first, highest last) since the
     * dispatcher fires the last-registered enabled callback.
     */
    private fun setupBackPressedCallbacks() {
        val bottomNavigatorCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                navigator.pop()
            }
        }
        onBackPressedDispatcher.addCallback(this, bottomNavigatorCallback)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                navigator.canGoBack.collectLatest { canGoBack ->
                    bottomNavigatorCallback.isEnabled = canGoBack
                }
            }
        }

        val playerBottomSheetCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                binding.playerBottomSheet.closePlayer()
            }
        }
        onBackPressedDispatcher.addCallback(this, playerBottomSheetCallback)
        playerBottomSheetCallback.isEnabled = binding.playerBottomSheet.isPlayerOpen

        val playerContainerBackstackCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                val playerContainerFragment =
                    supportFragmentManager.fragments.find { it is PlayerContainerFragment } as? PlayerContainerFragment
                playerContainerFragment?.onBackPressed()
                playerContainerCallbackUpdater?.invoke()
            }
        }
        onBackPressedDispatcher.addCallback(this, playerContainerBackstackCallback)

        fun syncPlayerContainerCallback() {
            val playerContainerFragment =
                supportFragmentManager.fragments.find { it is PlayerContainerFragment } as? PlayerContainerFragment
            val hasBackstack = playerContainerFragment != null && playerContainerFragment.getBackstackCount() > 0
            val isPlayerOpen = binding.playerBottomSheet.isPlayerOpen
            playerContainerBackstackCallback.isEnabled = isPlayerOpen && hasBackstack
            if (isPlayerOpen) {
                playerBottomSheetCallback.isEnabled = !hasBackstack
            }
        }
        playerContainerCallbackUpdater = ::syncPlayerContainerCallback

        val modalFragmentCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                val currentFragment = navigator.currentFragment()
                if (currentFragment is HasBackstack) {
                    val handled = currentFragment.onBackPressed()
                    if (!handled) {
                        navigator.pop()
                    }
                } else {
                    navigator.pop()
                }
            }
        }
        onBackPressedDispatcher.addCallback(this, modalFragmentCallback)

        val frameBottomSheetCallback = object : OnBackPressedCallback(bottomSheetTag != null) {
            override fun handleOnBackPressed() {
                frameBottomSheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
            }
        }
        onBackPressedDispatcher.addCallback(this, frameBottomSheetCallback)

        frameBottomSheetBehavior.addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
            override fun onSlide(bottomSheet: View, slideOffset: Float) {}
            override fun onStateChanged(bottomSheet: View, newState: Int) {
                frameBottomSheetCallback.isEnabled = newState != BottomSheetBehavior.STATE_COLLAPSED
                modalFragmentCallback.isEnabled = navigator.isShowingModal()
            }
        })

        val upNextMultiSelectCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                val fragment = supportFragmentManager.findFragmentByTag(UpNextFragment::class.java.name)
                (fragment as? UpNextFragment)?.multiSelectHelper?.isMultiSelecting = false
                isEnabled = false
            }
        }
        onBackPressedDispatcher.addCallback(this, upNextMultiSelectCallback)

        navigator.infoStream()
            .subscribe {
                modalFragmentCallback.isEnabled = navigator.isShowingModal()
                syncPlayerContainerCallback()
            }
            .also { disposables.add(it) }

        this.playerBottomSheetBackCallback = playerBottomSheetCallback
        this.upNextMultiSelectBackCallback = upNextMultiSelectCallback
        this.playerContainerBackCallback = playerContainerBackstackCallback
        this.modalFragmentBackCallback = modalFragmentCallback
        this.frameBottomSheetBackCallback = frameBottomSheetCallback
    }

    private var playerBottomSheetBackCallback: OnBackPressedCallback? = null
    private var upNextMultiSelectBackCallback: OnBackPressedCallback? = null
    private var playerContainerBackCallback: OnBackPressedCallback? = null
    private var modalFragmentBackCallback: OnBackPressedCallback? = null
    private var frameBottomSheetBackCallback: OnBackPressedCallback? = null
    private var playerContainerCallbackUpdater: (() -> Unit)? = null

    private var upNextMultiSelectObserver: Observer<Boolean>? = null

    private fun observeUpNextMultiSelectState(upNextFragment: UpNextFragment) {
        val liveData = upNextFragment.multiSelectHelper.isMultiSelectingLive
        upNextMultiSelectObserver?.let { liveData.removeObserver(it) }
        val observer = Observer<Boolean> { isMultiSelecting ->
            upNextMultiSelectBackCallback?.isEnabled = isUpNextShowing() && isMultiSelecting == true
        }
        upNextMultiSelectObserver = observer
        liveData.observe(this, observer)
    }

    private fun stopObservingUpNextMultiSelectState() {
        val observer = upNextMultiSelectObserver ?: return
        val fragment = supportFragmentManager.findFragmentByTag(UpNextFragment::class.java.name)
        (fragment as? UpNextFragment)?.multiSelectHelper?.isMultiSelectingLive?.removeObserver(observer)
        upNextMultiSelectObserver = null
        upNextMultiSelectBackCallback?.isEnabled = false
    }

    override fun onPlayerBackstackChanged() {
        playerContainerCallbackUpdater?.invoke()
    }

    override fun updateStatusBar() {
        val topFragment = supportFragmentManager.fragments.lastOrNull()
        val color = if (binding.playerBottomSheet.isPlayerOpen) {
            StatusBarIconColor.Light
        } else if (topFragment is BaseFragment) {
            topFragment.statusBarIconColor
        } else {
            null
        }

        if (color != null) {
            theme.updateWindowStatusBarIcons(window = window, statusBarIconColor = color)
        }
    }

    private fun updateNavAndStatusColors(playerOpen: Boolean, playingPodcast: Podcast?) {
        val navigationBarColor = if (playerOpen) {
            NavigationBarColor.Player(playingPodcast)
        } else {
            NavigationBarColor.Theme
        }

        theme.updateWindowNavigationBarColor(window = window, navigationBarColor = navigationBarColor)

        // Color the side bars of the screen if there is inset for areas such as cameras
        binding.root.setBackgroundColor(theme.getNavigationBarColor(navigationBarColor))

        updateStatusBar()
    }

    override fun onUpNextClicked() {
        showUpNextFragment(UpNextSource.MINI_PLAYER)
    }

    override fun onMiniPlayerLongClick() {
        MiniPlayerDialog(
            playbackManager = playbackManager,
            podcastManager = podcastManager,
            episodeManager = episodeManager,
            fragmentManager = supportFragmentManager,
            eventHorizon = eventHorizon,
            settings = settings,
        ).show(this)
    }

    private fun showUpNextFragment(source: UpNextSource) {
        eventHorizon.track(
            UpNextShownEvent(
                source = source.analyticsValue,
            ),
        )
        showBottomSheet(UpNextFragment.newInstance(source = source))
    }

    private fun setupEndOfYearLaunchBottomSheet() {
        val viewGroup = binding.modalBottomSheet
        viewGroup.removeAllViews()
        viewGroup.addView(
            ComposeView(viewGroup.context).apply {
                setContent {
                    val shouldShow by viewModel.shouldShowStoriesModal.collectAsState()
                    AppTheme(theme.activeTheme) {
                        EndOfYearLaunchBottomSheet(
                            parent = viewGroup,
                            shouldShow = shouldShow,
                            onClick = {
                                eventHorizon.track(
                                    EndOfYearModalTappedEvent(
                                        currentYear = EndOfYearManager.YEAR_TO_SYNC.value.toLong(),
                                    ),
                                )
                                showStoriesOrAccount(StoriesSource.MODAL.key)
                            },
                            onExpand = {
                                eventHorizon.track(
                                    EndOfYearModalShownEvent(
                                        currentYear = EndOfYearManager.YEAR_TO_SYNC.value.toLong(),
                                    ),
                                )
                                settings.setEndOfYearShowModal(false)
                            },
                            onCollapse = {
                                eventHorizon.track(
                                    EndOfYearModalDismissedEvent(
                                        currentYear = EndOfYearManager.YEAR_TO_SYNC.value.toLong(),
                                    ),
                                )
                            },
                        )
                    }
                }
            },
        )
    }

    private fun showEndOfYearModal() {
        viewModel.updateStoriesModalShowState(true)
        launch(Dispatchers.Main) {
            if (viewModel.isEndOfYearStoriesEligible()) setupEndOfYearLaunchBottomSheet()
        }
    }

    override fun showStoriesOrAccount(source: String) {
        if (viewModel.isSignedIn) {
            showStories(StoriesSource.fromString(source))
        } else {
            viewModel.waitingForSignInToShowStories = true
            openOnboardingFlow(OnboardingFlow.LoggedOut)
        }
    }

    private fun showStories(source: StoriesSource) {
        endOfYearActivityLauncher.launch(
            StoriesActivity.intent(activity = this, source = source),
        )
    }

    private fun setupPlayerViews(animateMiniPlayer: Boolean) {
        binding.playerBottomSheet.listener = this
        binding.playerBottomSheet.initializeBottomSheetBehavior()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.playbackState.collect { state ->
                    val lastPlaybackState = viewModel.lastPlaybackState
                    val isEpisodeChanged = lastPlaybackState?.episodeUuid != state.episodeUuid
                    val isPlaybackChanged = lastPlaybackState?.isPlaying == false && state.isPlaying

                    if (isEpisodeChanged || isPlaybackChanged) {
                        val episode = withContext(Dispatchers.Default) {
                            episodeManager.findEpisodeByUuid(state.episodeUuid)
                        }
                        if (episode?.isVideo == true && state.isPlaying) {
                            if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
                                binding.playerBottomSheet.openPlayer()
                            } else {
                                openFullscreenViewPlayer()
                            }
                        }
                    }

                    if (viewModel.isPlayerOpen && isEpisodeChanged) {
                        updateNavAndStatusColors(playerOpen = true, playingPodcast = state.podcast)
                    }

                    if (lastPlaybackState != null && (isEpisodeChanged || isPlaybackChanged) && settings.openPlayerAutomatically.value) {
                        binding.playerBottomSheet.openPlayer()
                    }

                    updatePlaybackState(state)

                    viewModel.lastPlaybackState = state
                }
            }
        }

        val upNextQueueChanges = playbackManager.upNextQueue.getChangesFlowWithLiveCurrentEpisode(episodeManager, podcastManager)
        val artworkConfigurationChanges = settings.artworkConfiguration.flow

        val combinedFlow = combine(upNextQueueChanges, artworkConfigurationChanges) { upNextQueue, artworkConfiguration ->
            upNextQueue to artworkConfiguration
        }
            .onEach { (upNextQueue, artworkConfiguration) ->
                binding.playerBottomSheet.setUpNext(
                    upNext = upNextQueue,
                    theme = theme,
                    shouldAnimateOnAttach = animateMiniPlayer,
                    useEpisodeArtwork = artworkConfiguration.useEpisodeArtwork,
                )
            }
            .catch { Timber.e(it) }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                combinedFlow.collect()
            }
        }

        viewModel.signInState.observe(this) { signinState ->
            val subscription = (signinState as? SignInState.SignedIn)?.subscription

            if (signinState.isSignedIn) {
                if (viewModel.waitingForSignInToShowStories) {
                    showStories(StoriesSource.USER_LOGIN)
                    viewModel.waitingForSignInToShowStories = false
                } else if (settings.getEndOfYearShowModal()) {
                    if (isWhatsNewShowing()) return@observe
                    showEndOfYearModal()
                }
            }

            if (subscription != null) {
                if (viewModel.shouldShowCancelled(subscription)) {
                    val cancelledFragment = SubCancelledFragment.newInstance()
                    showBottomSheet(cancelledFragment)
                }
            } else {
                applicationScope.launch { userEpisodeManager.removeCloudStatusFromFiles(playbackManager) }
            }

            if (viewModel.shouldShowTrialFinished(signinState)) {
                val trialFinished = TrialFinishedFragment()
                showBottomSheet(trialFinished)

                settings.setTrialFinishedSeen(true)
            }

            // Result is intentionally ignored; failures are logged internally by sendAuthToDataLayer
            lifecycleScope.launch { watchSync.sendAuthToDataLayer() }
        }

        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.CREATED) {
                viewModel.state.collect { state ->
                    if (state.shouldShowWhatsNew) {
                        showBottomSheet(
                            fragment = WhatsNewFragment(),
                        )
                        viewModel.onWhatsNewShown()
                    }
                }
            }
        }

        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.snackbarMessage.collect { messageResId ->
                    Snackbar.make(snackBarView(), getString(messageResId), Snackbar.LENGTH_LONG)
                        .show()
                }
            }
        }

        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.navigationState.collect { navigationState ->
                    when (navigationState) {
                        is NavigationState.BookmarksForCurrentlyPlaying -> showPlayerBookmarks()

                        is NavigationState.BookmarksForPodcastEpisode -> {
                            // Once episode container fragment is shown, bookmarks tab is shown from inside it based on the new source
                            openEpisodeDialog(
                                episodeUuid = navigationState.episode.uuid,
                                source = EpisodeViewSource.NOTIFICATION_BOOKMARK,
                                podcastUuid = navigationState.episode.podcastUuid,
                                forceDark = false,
                                autoPlay = false,
                            )
                        }

                        is NavigationState.BookmarksForUserEpisode -> {
                            // Bookmarks container is directly shown for user episode
                            val fragment = BookmarksContainerFragment.newInstance(navigationState.episode.uuid, SourceView.NOTIFICATION_BOOKMARK)
                            fragment.show(supportFragmentManager, "bookmarks_container")
                        }
                    }
                }
            }
        }

        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.snackbarMessage.collect { messageResId ->
                    Snackbar.make(snackBarView(), getString(messageResId), Snackbar.LENGTH_LONG)
                        .show()
                }
            }
        }

        frameBottomSheetBehavior.addBottomSheetCallback(object :
            BottomSheetBehavior.BottomSheetCallback() {
            override fun onSlide(bottomSheet: View, slideOffset: Float) {}

            override fun onStateChanged(bottomSheet: View, newState: Int) {
                settings.updatePlayerOrUpNextBottomSheetState(newState)
                if (newState == BottomSheetBehavior.STATE_COLLAPSED) {
                    val fragment = supportFragmentManager.findFragmentByTag(bottomSheetTag)

                    if (fragment is UpNextFragment) {
                        val source = fragment.args?.source?.analyticsValue ?: UpNextSourceType.Unknown
                        eventHorizon.track(
                            UpNextDismissedEvent(
                                source = source,
                            ),
                        )
                    }
                    fragment?.let(::removeBottomSheetFragment)

                    binding.playerBottomSheet.isDragEnabled = true
                    frameBottomSheetBehavior.swipeEnabled = false

                    updateNavAndStatusColors(playerOpen = viewModel.isPlayerOpen, playingPodcast = viewModel.lastPlaybackState?.podcast)
                    stopObservingUpNextMultiSelectState()
                } else {
                    binding.playerBottomSheet.isDragEnabled = false
                }
            }
        })
    }

    private fun setupBottomSheetTranslation() {
        frameBottomSheetBehavior.addBottomSheetCallback(OffsettingBottomSheetCallback(binding.frameBottomSheet))
    }

    override fun whatsNewDismissed(fromConfirmAction: Boolean) {
        if (fromConfirmAction) return
        if (settings.getEndOfYearShowModal()) showEndOfYearModal()
    }

    override fun getPlayerBottomSheetState(): Int {
        return binding.playerBottomSheet.sheetBehavior?.state ?: BottomSheetBehavior.STATE_COLLAPSED
    }

    override fun addPlayerBottomSheetCallback(callback: BottomSheetBehavior.BottomSheetCallback) {
        binding.playerBottomSheet.sheetBehavior?.addBottomSheetCallback(callback)
    }

    override fun removePlayerBottomSheetCallback(callback: BottomSheetBehavior.BottomSheetCallback) {
        binding.playerBottomSheet.sheetBehavior?.removeBottomSheetCallback(callback)
    }

    override fun lockPlayerBottomSheet(locked: Boolean) {
        binding.playerBottomSheet.isDragEnabled = !locked
    }

    private fun updatePlaybackState(state: PlaybackState) {
        binding.playerBottomSheet.setPlaybackState(state)

        if ((state.isPlaying || state.isBuffering) && settings.keepScreenAwake.value) {
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    override fun snackBarView(): View {
        return dialogSnackBarView() ?: playerSnackBarView() ?: binding.snackbarFragment
    }

    private fun dialogSnackBarView(): View? {
        return supportFragmentManager.fragments
            .filterIsInstance<BaseDialogFragment>()
            .lastOrNull { it.isAdded && it.dialog?.isShowing == true }
            ?.snackBarView()
    }

    private fun playerSnackBarView(): View? {
        return supportFragmentManager
            .takeIf { viewModel.isPlayerOpen }
            ?.fragments
            ?.firstNotNullOfOrNull { it as? PlayerContainerFragment }
            ?.snackBarView()
    }

    override fun setFullScreenDarkOverlayViewVisibility(visible: Boolean) {
        binding.fullScreenDarkOverlayView.isVisible = visible
    }

    override fun onMiniPlayerHidden() {
        updateSnackbarPosition(miniPlayerOpen = false)
        settings.updateBottomInset(0)
    }

    private fun updateSnackbarPosition(miniPlayerOpen: Boolean) {
        binding.snackbarFragment.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            bottomMargin = (if (miniPlayerOpen) miniPlayerHeight else 0) + bottomNavigationHeight
        }
    }

    override fun onMiniPlayerVisible() {
        updateSnackbarPosition(miniPlayerOpen = true)
        settings.updateBottomInset(miniPlayerHeight)

        // Handle up next shortcut
        if (intent.getStringExtra(EXTRA_PAGE) == ShowUpNextModalDeepLink.pageId) {
            intent.removeExtra(EXTRA_PAGE)
            binding.playerBottomSheet.openPlayer()
            showUpNextFragment(UpNextSource.UP_NEXT_SHORTCUT)
        }
    }

    override fun onPlayerBottomSheetSlide(bottomSheetView: View, slideOffset: Float) {
        val view = binding.bottomContainer
        view.doOnLayout {
            val targetPosition = 2 * view.height * slideOffset
            view.spring(TRANSLATION_Y).animateToFinalPosition(targetPosition)
        }
    }

    override fun updateSystemColors() {
        updateNavAndStatusColors(viewModel.isPlayerOpen, viewModel.lastPlaybackState?.podcast)
    }

    override fun onPlayerOpen() {
        launch {
            val isVideo = playbackManager.upNextQueue.currentEpisode?.isVideo ?: false
            if (isVideo) {
                playbackManager.preparePlayer()
            }
        }

        updateNavAndStatusColors(playerOpen = true, playingPodcast = viewModel.lastPlaybackState?.podcast)
        UiUtil.hideKeyboard(binding.root)

        viewModel.isPlayerOpen = true
        playerContainerCallbackUpdater?.invoke()

        val playerContainerFragment = supportFragmentManager.fragments
            .find { it is PlayerContainerFragment } as? PlayerContainerFragment
        playerContainerFragment?.onPlayerOpen()
    }

    override fun onPlayerClosed() {
        updateNavAndStatusColors(playerOpen = false, playingPodcast = null)

        viewModel.isPlayerOpen = false
        viewModel.closeMultiSelect()
        playerBottomSheetBackCallback?.isEnabled = false
        playerContainerCallbackUpdater?.invoke()

        val playerContainerFragment = supportFragmentManager.fragments
            .find { it is PlayerContainerFragment } as? PlayerContainerFragment
        playerContainerFragment?.onPlayerClose()
    }

    override fun openTab(tabId: Int) {
        navigator.switchTab(tabId)
    }

    private suspend fun openLandingTabAfterOnboarding() {
        openTab(VR.id.navigation_podcasts)
    }

    override fun showBottomSheet(fragment: Fragment) {
        supportFragmentManager.commitNow {
            bottomSheetTag = fragment::class.java.name
            replace(R.id.frameBottomSheet, fragment, bottomSheetTag)
        }

        frameBottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
        frameBottomSheetBackCallback?.isEnabled = true
        frameBottomSheetBehavior.swipeEnabled = true
        binding.frameBottomSheet.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        if (fragment is UpNextFragment) {
            observeUpNextMultiSelectState(fragment)
        } else {
            stopObservingUpNextMultiSelectState()
        }
    }

    override fun closeBottomSheet() {
        frameBottomSheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
        frameBottomSheetBackCallback?.isEnabled = false
        binding.frameBottomSheet.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    override fun closeDialogs() {
        supportFragmentManager.fragments.filterIsInstance<DialogFragment>().forEach {
            it.dismissAllowingStateLoss()
        }
    }

    override fun isUpNextShowing() = bottomSheetTag == UpNextFragment::class.java.name

    private fun isWhatsNewShowing() = bottomSheetTag == WhatsNewFragment::class.java.name

    private fun removeBottomSheetFragment(fragment: Fragment) {
        val tag = fragment::class.java.name
        supportFragmentManager.findFragmentByTag(tag)?.let {
            supportFragmentManager.commitNow(allowStateLoss = true) {
                remove(it)

                updateStatusBar()
                bottomSheetTag = null

                if (bottomSheetQueue.isNotEmpty()) {
                    val next = bottomSheetQueue.removeAt(0)
                    next?.invoke()
                }
            }
        }
    }

    override fun showModal(fragment: Fragment) {
        fragment.enterTransition = Slide()
        fragment.exitTransition = Slide()
        navigator.addFragment(fragment, modal = true)

        updateStatusBar()
    }

    override fun closeModal(fragment: Fragment) {
        navigator.pop()
        updateStatusBar()
    }

    override fun openPlayer() {
        binding.playerBottomSheet.openPlayer()
    }

    override fun closePlayer() {
        binding.playerBottomSheet.closePlayer()
    }

    override fun onPlayClicked() {
        if (playbackManager.shouldWarnAboutPlayback()) {
            launch {
                // show the stream warning if the episode isn't downloaded
                playbackManager.getCurrentEpisode()?.let { episode ->
                    launch(Dispatchers.Main) {
                        if (episode.isDownloaded) {
                            playbackManager.playQueue(SourceView.MINIPLAYER)
                            warningsHelper.showBatteryWarningSnackbarIfAppropriate()
                        } else {
                            warningsHelper.streamingWarningDialog(episode = episode, sourceView = SourceView.MINIPLAYER)
                                .show(supportFragmentManager, "streaming dialog")
                        }
                    }
                }
            }
        } else {
            playbackManager.playQueue(SourceView.MINIPLAYER)
            warningsHelper.showBatteryWarningSnackbarIfAppropriate()
        }
    }

    override fun onPauseClicked() {
        playbackManager.pause(sourceView = SourceView.MINIPLAYER)
    }

    override fun onSkipBackwardClicked() {
        playbackManager.skipBackward(sourceView = SourceView.MINIPLAYER)
    }

    override fun onSkipForwardClicked() {
        playbackManager.skipForward(sourceView = SourceView.MINIPLAYER)
    }

    override fun addFragment(fragment: Fragment, onTop: Boolean) {
        navigator.addFragment(fragment, onTop = onTop)
    }

    override fun replaceFragment(fragment: Fragment) {
        navigator.addFragment(fragment)
    }

    override fun closeToRoot() {
        navigator.clearAll()
    }

    override fun closePodcastsToRoot() {
        navigator.reset(tab = VR.id.navigation_podcasts, resetRootFragment = true)
    }

    override fun closeFiltersToRoot() {
        navigator.reset(tab = VR.id.navigation_filters, resetRootFragment = true)
    }

    override fun setSupportActionBar(toolbar: Toolbar?) {
        super.setSupportActionBar(toolbar)

        if (!navigator.isAtRootOfStack()) {
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            supportActionBar?.setDisplayShowHomeEnabled(true)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    override fun onSearchEpisodeClick(
        episodeUuid: String,
        podcastUuid: String,
        source: EpisodeViewSource,
    ) {
        openEpisodeDialog(
            episodeUuid = episodeUuid,
            source = source,
            podcastUuid = podcastUuid,
            forceDark = false,
            autoPlay = false,
        )
    }

    override fun onSearchPodcastClick(podcastUuid: String, source: SourceView) {
        val fragment = PodcastFragment.newInstance(podcastUuid, source)
        addFragment(fragment)
    }

    override fun onSearchFolderClick(folderUuid: String) {
        val fragment = PodcastsFragment.newInstance(folderUuid)
        addFragment(fragment)
    }

    override fun showAccountUpgradeNow(autoSelectPlus: Boolean) {
        showAccountUpgradeNowDialog(autoSelectPlus = autoSelectPlus)
    }

    private fun showAccountUpgradeNowDialog(autoSelectPlus: Boolean = false) {
        val observer: Observer<SignInState> = Observer { value ->
            val intent = if (value.isSignedInAsFree) {
                AccountActivity.newUpgradeInstance(this)
            } else if (autoSelectPlus) {
                AccountActivity.newAutoSelectPlusInstance(
                    this,
                )
            } else {
                Intent(this, AccountActivity::class.java)
            }
            startActivity(intent)
        }

        viewModel.signInState.observeOnce(this, observer)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent, null)
    }

    @Suppress("DEPRECATION")
    private fun handleIntent(intent: Intent?, savedInstanceState: Bundle?) {
        val action = intent?.action
        if (action == null || savedInstanceState != null) {
            return
        }

        try {
            val safeUri = intent.data?.buildUpon()?.clearQuery()?.build() // Remove query parameters from logging
            LogBuffer.i("DeepLink", "Opening deep link: $intent. Safe URI: $safeUri")
            when (val deepLink = deepLinkFactory.create(intent)) {
                is AppOpenDeepLink -> {
                    closeToRoot()
                }

                is DownloadsDeepLink -> {
                    closePlayer()
                    closeToRoot()
                    addFragment(ProfileEpisodeListFragment.newInstance(ProfileEpisodeListFragment.Mode.Downloaded))
                }

                is AddBookmarkDeepLink -> {
                    launch {
                        val bookmarkArguments = viewModel.createBookmarkArguments(bookmarkUuid = null)
                        if (bookmarkArguments != null) {
                            bookmarkActivityLauncher.launch(BookmarkActivity.launchIntent(this@MainActivity, bookmarkArguments))
                        }
                    }
                }

                is ChangeBookmarkTitleDeepLink -> {
                    launch {
                        val bookmarkArguments = viewModel.createBookmarkArguments(deepLink.bookmarkUuid)
                        if (bookmarkArguments != null) {
                            bookmarkActivityLauncher.launch(BookmarkActivity.launchIntent(this@MainActivity, bookmarkArguments))
                        }
                        notificationHelper.removeNotification(intent.extras, Settings.NotificationId.BOOKMARK.value)
                    }
                }

                is ShowBookmarkDeepLink -> {
                    viewModel.viewBookmark(deepLink.bookmarkUuid)
                }

                is DeleteBookmarkDeepLink -> {
                    viewModel.deleteBookmark(deepLink.bookmarkUuid)
                    notificationHelper.removeNotification(intent.extras, Settings.NotificationId.BOOKMARK.value)
                }

                is ShowPodcastDeepLink -> {
                    closePlayer()
                    openPodcastPage(deepLink.podcastUuid, deepLink.sourceView)
                }

                is ShowEpisodeDeepLink -> {
                    openEpisodeDialog(
                        episodeUuid = deepLink.episodeUuid,
                        podcastUuid = deepLink.podcastUuid,
                        source = EpisodeViewSource.fromString(deepLink.sourceView),
                        forceDark = false,
                        autoPlay = deepLink.autoPlay,
                        startTimestamp = deepLink.startTimestamp,
                        endTimestamp = deepLink.endTimestamp,
                    )
                }

                is ShowPodcastsDeepLink -> {
                    closePlayer()
                    openTab(VR.id.navigation_podcasts)
                }

                is ShowDiscoverDeepLink -> {
                    closePlayer()
                    openTab(VR.id.navigation_podcasts)
                }

                is ShowUpNextModalDeepLink -> {
                    // Do nothig, handled in onMiniPlayerVisible()
                }

                is ShowUpNextTabDeepLink -> {
                    closePlayer()
                    openTab(VR.id.navigation_upnext)
                }

                is ShowPlaylistDeepLink -> {
                    val type = Playlist.Type.fromValue(deepLink.playlistType) ?: return
                    closePlayer()
                    openTab(VR.id.navigation_filters)
                    addFragment(PlaylistFragment.newInstance(deepLink.playlistUuid, type))
                }

                is CreateAccountDeepLink -> {
                    openOnboardingFlow(OnboardingFlow.LoggedOut)
                }

                is ShowFiltersDeepLink -> {
                    closePlayer()
                    openTab(VR.id.navigation_filters)
                }

                is PocketCastsWebsiteGetDeepLink -> {
                    // Do nothing when the user goes to https://pocketcasts.com/get it should either open the play store or the user's app
                }

                is ReferralsDeepLink -> {
                    openReferralClaim(deepLink.code)
                }

                is ShowPodcastFromUrlDeepLink -> {
                    openPodcastUrl(deepLink.url)
                }

                is SonosDeepLink -> {
                    startActivityForResult(
                        SonosAppLinkActivity.buildIntent(deepLink.state, this),
                        SonosAppLinkActivity.SONOS_APP_ACTIVITY_RESULT,
                    )
                }

                is ShareListDeepLink -> {
                    addFragment(ShareListIncomingFragment.newInstance(deepLink.path, SourceView.fromString(deepLink.sourceView)))
                }

                is CloudFilesDeepLink -> {
                    openCloudFiles()
                }

                is UpsellDeepLink -> {
                    closePlayer()
                    openOnboardingFlow(OnboardingFlow.Upsell(OnboardingUpgradeSource.DEEP_LINK))
                }

                is SmartFoldersDeepLink -> {
                    if (supportFragmentManager.findFragmentByTag("suggested_folders") == null) {
                        closePlayer()
                        SuggestedFoldersFragment.newInstance(SuggestedFoldersFragment.Source.DEEPLINK).show(supportFragmentManager, "suggested_folders")
                    }
                    openTab(VR.id.navigation_podcasts)
                }

                is UpgradeAccountDeepLink -> {
                    showAccountUpgradeNowDialog()
                }

                is PromoCodeDeepLink -> {
                    openPromoCode(deepLink.code)
                }

                is NativeShareDeepLink -> {
                    openSharingUrl(deepLink)
                }

                is OpmlImportDeepLink -> {
                    closePlayer()
                    OpmlImportTask.run(deepLink.uri, this)
                }

                is ImportDeepLink -> {
                    openImport()
                }

                is StaffPicksDeepLink -> {
                    val podcastListFragment = supportFragmentManager.fragments.find { it is PodcastGridListFragment } as? PodcastGridListFragment
                    if (podcastListFragment?.listUuid != STAFF_PICKS_LIST_ID) {
                        openDiscoverListDeeplink(STAFF_PICKS_LIST_ID)
                    }
                }

                is TrendingDeepLink -> {
                    val podcastListFragment = supportFragmentManager.fragments.find { it is PodcastGridListFragment } as? PodcastGridListFragment
                    if (podcastListFragment?.inferredId != TRENDING) {
                        openDiscoverListDeeplink(TRENDING)
                    }
                }

                is RecommendationsDeepLink -> {
                    val podcastListFragment = supportFragmentManager.fragments.find { it is PodcastGridListFragment } as? PodcastGridListFragment
                    if (podcastListFragment?.inferredId != RECOMMENDATIONS_USER) {
                        openDiscoverListDeeplink(RECOMMENDATIONS_USER)
                    }
                }

                is PlayFromSearchDeepLink -> {
                    playbackManager.mediaSessionManager.playFromSearchExternal(deepLink.query)
                }

                is AssistantDeepLink -> {
                    // This is what the assistant sends us when it doesn't know what to do and just opens the app. Assume the user wants to play.
                    playbackManager.playQueue()
                }

                is SignInDeepLink -> {
                    val onboardingFlow = when (SourceView.fromString(deepLink.sourceView)) {
                        SourceView.ENGAGE_SDK_SIGN_IN -> OnboardingFlow.EngageSdk
                        else -> OnboardingFlow.LoggedOut
                    }
                    openOnboardingFlow(onboardingFlow)
                }

                is ThemesDeepLink -> {
                    closePlayer()
                    addFragment(AppearanceSettingsFragment.newInstance())
                }

                is DeveloperOptionsDeeplink -> {
                    closePlayer()
                    addFragment(DeveloperFragment())
                }

                null -> {
                    LogBuffer.i("DeepLink", "Did not find any matching deep link for: $intent")
                }
            }
        } catch (e: Exception) {
            Timber.e(e)
            crashLogging.sendReport(e)
        }
    }

    private fun openDiscoverListDeeplink(listId: String) {
        closePlayer()
        openTab(VR.id.navigation_podcasts)
        lifecycleScope.launch {
            val discoverList = discoverDeepLinkManager.getDiscoverList(listId, resources) ?: return@launch
            val fragment = PodcastListFragment.newInstance(discoverList)
            addFragment(fragment)
        }
    }

    private fun openReferralClaim(code: String) {
        settings.referralClaimCode.set(code, false)
        openTab(VR.id.navigation_profile)
        val fragment = ReferralsGuestPassFragment.newInstance(ReferralsGuestPassFragment.ReferralsPageType.Claim)
        showBottomSheet(fragment)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        theme.setupThemeForConfig(this, newConfig)
    }

    override fun openCloudFiles() {
        if (supportFragmentManager.fragments.find { it is CloudFilesFragment } == null) {
            addFragment(CloudFilesFragment())
        }
    }

    override fun openPodcastPage(uuid: String, sourceView: String?) {
        closePlayer()
        frameBottomSheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED

        val currentFragment = navigator.currentFragment()
        if (currentFragment is PodcastFragment && uuid == currentFragment.podcastUuid) return // We are already showing it
        addFragment(PodcastFragment.newInstance(podcastUuid = uuid, sourceView = SourceView.fromString(sourceView)))
    }

    @Suppress("DEPRECATION")
    override fun openEpisodeDialog(
        episodeUuid: String?,
        source: EpisodeViewSource,
        podcastUuid: String?,
        forceDark: Boolean,
        autoPlay: Boolean,
        startTimestamp: Duration?,
        endTimestamp: Duration?,
    ) {
        episodeUuid ?: return

        // If a clip has both start and end we don't open it in the app.
        // We do not have a capability of playing a section of an episode between some timestamps.
        if (startTimestamp != null && endTimestamp != null) {
            val url = "${Settings.SERVER_SHORT_URL}/episode/$episodeUuid?t=${startTimestamp.inWholeSeconds},${endTimestamp.inWholeSeconds}"
            WebViewActivity.show(this, getString(LR.string.clip_title), url)
            return
        }

        launch(Dispatchers.Main.immediate) {
            val fragment = when (val localEpisode = withContext(Dispatchers.Default) { episodeManager.findEpisodeByUuid(episodeUuid) }) {
                is UserEpisode -> {
                    CloudFileBottomSheetFragment.newInstance(localEpisode.uuid, forceDark = true, source)
                }

                is PodcastEpisode -> {
                    EpisodeContainerFragment.newInstance(
                        episodeUuid = localEpisode.uuid,
                        source = source,
                        podcastUuid = localEpisode.podcastUuid,
                        forceDark = forceDark,
                        timestamp = startTimestamp,
                        autoPlay = autoPlay,
                    )
                }

                null -> {
                    val dialog = android.app.ProgressDialog.show(this@MainActivity, getString(LR.string.loading), getString(LR.string.please_wait), true)
                    val searchResult = serviceManager.getSharedItemDetails("/social/share/show/$episodeUuid").getOrNull()
                    dialog.hide()
                    searchResult?.episode?.let {
                        EpisodeContainerFragment.newInstance(
                            episodeUuid = it.uuid,
                            source = source,
                            podcastUuid = it.podcastUuid,
                            forceDark = forceDark,
                            timestamp = startTimestamp,
                            autoPlay = autoPlay,
                        )
                    }
                }
            }
            fragment?.showAllowingStateLoss(supportFragmentManager, "episode_card")
        }
    }

    @Suppress("DEPRECATION")
    private fun openPodcastUrl(url: String?) {
        url ?: return

        val dialog = android.app.ProgressDialog.show(this, getString(LR.string.loading), getString(LR.string.please_wait), true)
        lifecycleScope.launch {
            val result = serviceManager
                .searchForPodcasts(url)
                .onFailure { error ->
                    UiUtil.displayAlertError(
                        context = this@MainActivity,
                        message = error.message ?: getString(LR.string.podcast_add_failed),
                        null,
                    )
                }
                .getOrNull()

            UiUtil.hideProgressDialog(dialog)
            if (result != null) {
                val podcastUuid = result.searchResults.firstOrNull()?.uuid
                if (podcastUuid != null) {
                    openPodcastPage(podcastUuid)
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun openSharingUrl(deepLink: NativeShareDeepLink) {
        // If a clip has both start and end we don't open it in the app.
        // We do not have a capability of playing a section of an episode between some timestamps.
        if (deepLink.startTimestamp != null && deepLink.endTimestamp != null) {
            WebViewActivity.show(this, getString(LR.string.clip_title), deepLink.uri.toString())
            return
        }

        val dialog = android.app.ProgressDialog.show(this, getString(LR.string.loading), getString(LR.string.please_wait), true)
        lifecycleScope.launch {
            val result = serviceManager
                .getSharedItemDetails(deepLink.sharePath)
                .onFailure { error ->
                    Timber.e(error)
                    UiUtil.displayAlertError(
                        this@MainActivity,
                        getString(LR.string.podcast_share_open_fail_title),
                        getString(LR.string.podcast_share_open_fail),
                        null,
                    )
                }
                .getOrNull()

            UiUtil.hideProgressDialog(dialog)
            if (result != null) {
                val podcastUuid = result.podcast.uuid
                if (podcastUuid.isBlank()) {
                    UiUtil.displayAlertError(
                        this@MainActivity,
                        getString(LR.string.podcast_share_open_fail_title),
                        getString(LR.string.podcast_share_open_fail),
                        null,
                    )
                    return@launch
                }

                val episode = result.episode
                if (episode != null) {
                    openEpisodeDialog(
                        episodeUuid = episode.uuid,
                        source = EpisodeViewSource.SHARE,
                        podcastUuid = podcastUuid,
                        forceDark = false,
                        autoPlay = false,
                        startTimestamp = deepLink.startTimestamp,
                    )
                } else {
                    openPodcastPage(podcastUuid)
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun openPromoCode(code: String) {
        val accountIntent = AccountActivity.promoCodeInstance(this, code)
        startActivityForResult(accountIntent, PROMOCODE_REQUEST_CODE)
    }

    private fun showUpgradedFromPromoCode(description: String) {
        openTab(VR.id.navigation_profile)
        PromoCodeUpgradedFragment.newInstance(description)
            .show(supportFragmentManager, "upgraded_from_promocode")
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == SonosAppLinkActivity.SONOS_APP_ACTIVITY_RESULT) {
            setResult(Activity.RESULT_OK, data)
            finish()
        } else if (requestCode == PROMOCODE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val message = data?.getStringExtra(AccountActivity.PROMO_CODE_RETURN_DESCRIPTION)
            showUpgradedFromPromoCode(message ?: "")
        }
    }

    private fun trackTabOpened(tab: Int, isInitial: Boolean = false) {
        val event = when (tab) {
            VR.id.navigation_podcasts -> PodcastsTabOpenedEvent(
                initial = isInitial,
            )

            VR.id.navigation_upnext -> UpNextTabOpenedEvent(
                initial = isInitial,
            )

            VR.id.navigation_filters -> FiltersTabOpenedEvent(
                initial = isInitial,
            )

            VR.id.navigation_discover -> DiscoverTabOpenedEvent(
                initial = isInitial,
            )

            VR.id.navigation_profile -> ProfileTabOpenedEvent(
                initial = isInitial,
            )

            else -> {
                Timber.e("Can't open invalid tab")
                null
            }
        }
        event?.let(eventHorizon::track)
    }

    override fun checkNotificationPermission(onPermissionGranted: () -> Unit) {
        checkForNotificationPermission(onPermissionGranted)
    }

    private fun showPlayerBookmarks() {
        openPlayer()
        launch {
            delay(1000) // To let the player open and load tabs
            withContext(Dispatchers.Main) {
                val playerContainerFragment =
                    supportFragmentManager.fragments.find { it is PlayerContainerFragment } as? PlayerContainerFragment
                playerContainerFragment?.openBookmarks()
            }
        }
    }

    private fun showViewBookmarksSnackbar(
        result: BookmarkActivityContract.BookmarkResult?,
    ) {
        val view = snackBarView()
        if (result == null) return

        val snackbarMessage = if (result.isExistingBookmark) {
            getString(LR.string.bookmark_updated, result.title)
        } else {
            getString(LR.string.bookmark_added, result.title)
        }

        val action = View.OnClickListener {
            showPlayerBookmarks()
        }

        Snackbar.make(view, snackbarMessage, Snackbar.LENGTH_LONG)
            .setAction(LR.string.settings_view, action)
            .show()
    }

    private fun openImport() {
        closePlayer()
        openTab(VR.id.navigation_profile)
        addFragment(SettingsFragment())
        addFragment(ExportSettingsFragment())
    }

    private fun setupAppReviewPrompt() {
        lifecycleScope.launch {
            appReviewManager.showPromptSignal
                .flowWithLifecycle(lifecycle, Lifecycle.State.RESUMED)
                .onStart { delay(3.seconds) } // Do not blast user with a review immediately on start
                .collect { signal ->
                    if (canDisplayAppRatingsPrompt(signal.reason)) {
                        AppReviewDialogFragment
                            .newInstance(signal.reason, signal.reviewInfo)
                            .show(supportFragmentManager, "app_review_prompt")
                        signal.consume()
                    } else {
                        signal.ignore()
                    }
                }
        }
    }

    private fun canDisplayAppRatingsPrompt(reason: AppReviewReason): Boolean {
        return reason == AppReviewReason.DevelopmentTrigger || (
            FeatureFlag.isEnabled(Feature.IMPROVE_APP_RATINGS) &&
                !binding.root.wasTouchedInLast(2.seconds) &&
                frameBottomSheetBehavior.state == BottomSheetBehavior.STATE_COLLAPSED &&
                !viewModel.shouldShowStoriesModal.value &&
                !binding.playerBottomSheet.isPlayerOpen &&
                isAtRootOfStack() &&
                isNoDialogShown() &&
                areChildrenAtRootOfStack() &&
                isNoChildDialogShown()
            )
    }

    private fun isAtRootOfStack(): Boolean {
        return navigator.isAtRootOfStack() && supportFragmentManager.isAtRootOfStack()
    }

    private fun isNoDialogShown(): Boolean {
        return !navigator.isShowingModal() && supportFragmentManager.isNoDialogShown()
    }

    private fun areChildrenAtRootOfStack(): Boolean {
        return childrenWithBackStack.all { it.getBackstackCount() == 0 } &&
            supportFragmentManager.fragments
                .filter { fragment -> fragment.host != null }
                .all { fragment -> fragment.childFragmentManager.isAtRootOfStack() }
    }

    private fun isNoChildDialogShown(): Boolean {
        return supportFragmentManager.fragments
            .filter { fragment -> fragment.host != null }
            .all { fragment -> fragment.childFragmentManager.isNoDialogShown() }
    }

    private fun FragmentManager.isAtRootOfStack(): Boolean {
        return backStackEntryCount == 0
    }

    private fun FragmentManager.isNoDialogShown(): Boolean {
        return fragments.none { it is DialogFragment }
    }
}
